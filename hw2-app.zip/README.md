<h1>Developed by Dylan Yue and Ryan Uyeki </h1>
<h2>To run frontend testcases (from the frontend folder): npm test</h2>
<h2>To run backend testcases (from the root directory): python -m pytest backend/app_test.py</h2>